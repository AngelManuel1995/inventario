module.exports = {
    mongoPort: process.env.MONGOPORT,
    mongoDatabase: process.env.MONGODATABASE,
    mongoUser: process.env.MONGOUSER,
    mongoPassword: process.env.MONGOPASSWORD,
    mongoHost: process.env.MONGOHOST,
};